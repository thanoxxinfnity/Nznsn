Mixamo Auto-Rigger ke liye models (FBX, texture andar embedded, 1024px)
1. mixamo.com -> Upload Character -> ek ek FBX
2. Auto-Rigger: chin, wrists, elbows, knees, groin markers lagao. Skeleton: "Standard Skeleton (65)" ya "Full body with fingers"
3. Download: Format FBX Binary (.fbx), Pose T-pose, "With Skin" (har character ka sirf ek baar), uske baad animations "Without Skin"
Naam: <ModelNaam>_WithSkin.fbx
Pehle in 3 ko karo (haath ke tukde kharab): M01_Gudiya, Z01_MasterJi, Z02_NurseDoll
Baaki: M02 Teddy, M06 Monkey (bhaalu/bandar humanoid jaise), M07 Clown, M08 Soldier, Z03 Doctor (pehle se theek, optional)
